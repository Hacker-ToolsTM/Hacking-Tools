This tool is used at your own risk.
Don't try to hack if you don't know how to hack,
the cops can take you and you can go in jail for a long, long time.
But don't worry about that now!
Let's have fun!